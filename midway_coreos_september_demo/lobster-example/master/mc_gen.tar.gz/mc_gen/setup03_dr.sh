#!/bin/bash
source /cvmfs/cms.cern.ch/cmsset_default.sh
export SCRAM_ARCH=slc6_amd64_gcc493
if [ -r CMSSW_7_6_1/src ] ; then 
 echo release CMSSW_7_6_1 already exists
else
scram p CMSSW CMSSW_7_6_1
fi
cd CMSSW_7_6_1/src
eval `scram runtime -sh`



scram b
cd ../../
cmsDriver.py step1 --filein "dbs:/ttHToTT_M125_13TeV_powheg_pythia8/RunIISummer15GS-MCRUN2_71_V1-v1/GEN-SIM" --fileout file:HIG-RunIIFall15DR76-00243_step1.root --pileup_input "dbs:/MinBias_TuneCUETP8M1_13TeV-pythia8/RunIISummer15GS-MCRUN2_71_V1-v2/GEN-SIM" --mc --eventcontent RAWSIM --pileup 2015_25ns_FallMC_matchData_PoissonOOTPU --datatier GEN-SIM-RAW --conditions 76X_mcRun2_asymptotic_v12 --step DIGI,L1,DIGI2RAW,HLT:@frozen25ns --era Run2_25ns --python_filename HIG-RunIIFall15DR76-00243_1_cfg.py --no_exec --customise Configuration/DataProcessing/Utils.addMonitoring -n 82 || exit $? ; 

cmsDriver.py step2 --filein file:HIG-RunIIFall15DR76-00243_step1.root --fileout file:HIG-RunIIFall15DR76-00243.root --mc --eventcontent AODSIM,DQM --runUnscheduled --datatier AODSIM,DQMIO --conditions 76X_mcRun2_asymptotic_v12 --step RAW2DIGI,L1Reco,RECO,EI,DQM:DQMOfflinePOGMC --era Run2_25ns --python_filename HIG-RunIIFall15DR76-00243_2_cfg.py --no_exec --customise Configuration/DataProcessing/Utils.addMonitoring -n 82 || exit $? ; 

