#!/bin/bash
source /cvmfs/cms.cern.ch/cmsset_default.sh
export SCRAM_ARCH=slc6_amd64_gcc493
if [ -r CMSSW_7_6_3/src ] ; then 
 echo release CMSSW_7_6_3 already exists
else
scram p CMSSW CMSSW_7_6_3
fi
cd CMSSW_7_6_3/src
eval `scram runtime -sh`



scram b
cd ../../
cmsDriver.py step1 --filein "dbs:/ttHToTT_M125_13TeV_powheg_pythia8/RunIIFall15DR76-PU25nsData2015v1_76X_mcRun2_asymptotic_v12-v1/AODSIM" --fileout file:HIG-RunIIFall15MiniAODv2-00224.root --mc --eventcontent MINIAODSIM --runUnscheduled --datatier MINIAODSIM --conditions 76X_mcRun2_asymptotic_v12 --step PAT --era Run2_25ns --python_filename HIG-RunIIFall15MiniAODv2-00224_1_cfg.py --no_exec --customise Configuration/DataProcessing/Utils.addMonitoring -n 1920 || exit $? ; 

